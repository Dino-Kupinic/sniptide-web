Each folder holds one .env test case and a compose.yaml for Docker Compose.
Run every loader from the case folder, from an empty environment (env -i), and print the variables it set.

dotenv          node -e 'require("dotenv").config(); console.log(process.env.PORT)'
Node.js         node --env-file=.env -p process.env.PORT
Bun             bun --env-file=.env -e 'console.log(process.env.PORT)'
Next.js         require("@next/env").loadEnvConfig(process.cwd())
Vite            import { loadEnv } from "vite"; loadEnv("development", process.cwd(), "")
Deno            deno run -A --env-file=.env script.js
Ruby            ruby -e 'require "dotenv"; Dotenv.load(".env"); puts ENV["PORT"]'
python-dotenv   python3 -c 'import os; from dotenv import load_dotenv; load_dotenv(".env"); print(os.environ.get("PORT"))'
Go              godotenv.Load(".env")
Bash            bash -c 'set -a; . ./.env; set +a; printenv PORT'
Compose         docker compose config --format json

shell_wins: export PORT=4000 before loading.
Results: https://sniptide.com/blog/env-file
